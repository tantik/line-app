const sb = window.supabaseClient;
const env = window.appEnv;

if (!sb) {
  throw new Error("Supabase client is not initialized");
}

if (!env) {
  throw new Error("App env is not initialized");
}

const state = {
  catalog: null,
  services: [],
  staff: [],
  selectedService: null,
  selectedStaff: null,
  selectedDate: "",
  selectedTime: "",
  createdBooking: null,
  step: 1
};

const qs = {
  loading: document.getElementById("loadingOverlay"),
  servicesList: document.getElementById("servicesList"),
  staffList: document.getElementById("staffList"),
  timeList: document.getElementById("timeList"),
  bookingDate: document.getElementById("bookingDate"),
  customerName: document.getElementById("customerName"),
  customerPhone: document.getElementById("customerPhone")
};

document.addEventListener("DOMContentLoaded", init);

async function init() {
  bindUi();

  try {
    setLoading(true);
    await loadCatalog();
    renderStep();
    renderServices();
    renderStaff();
    initDate();
    updateSummary();
  } catch (error) {
    console.error("init error:", error);
    toast("初期化に失敗しました");
  } finally {
    setLoading(false);
  }
}

function bindUi() {
  document.querySelectorAll("[data-go-step]").forEach((btn) => {
    btn.addEventListener("click", () => goToStep(Number(btn.dataset.goStep)));
  });

  document.querySelectorAll("[data-go-lead]").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.getElementById("leadSection")?.scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
    });
  });

  document.getElementById("backBtn")?.addEventListener("click", handleBack);

  document.getElementById("clearStaffBtn")?.addEventListener("click", () => {
    state.selectedStaff = null;
    state.selectedTime = "";
    renderStaff();
    renderTimeListEmpty("担当者を選択してください");
    updateSummary();
  });

  document.getElementById("toStep2Btn")?.addEventListener("click", () => {
    if (!state.selectedService) return toast("サービスを選択してください");
    goToStep(2);
  });

  document.getElementById("toStep3Btn")?.addEventListener("click", () => {
    if (!state.selectedDate || !state.selectedTime || !state.selectedStaff) {
      return toast("日付・時間・担当者を選択してください");
    }
    fillReview();
    goToStep(3);
  });

  document.getElementById("backTo2Btn")?.addEventListener("click", () => goToStep(2));
  document.getElementById("confirmBookingBtn")?.addEventListener("click", submitBooking);
  document.getElementById("restartBtn")?.addEventListener("click", resetBookingFlow);

  document.getElementById("openLeadBtn")?.addEventListener("click", () => {
    document.getElementById("leadSection")?.scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
  });

  document.getElementById("sendLeadBtn")?.addEventListener("click", submitLead);
  document.getElementById("confirmTokenBtn")?.addEventListener("click", () => changeCreatedBookingStatus("confirm"));
  document.getElementById("cancelTokenBtn")?.addEventListener("click", () => changeCreatedBookingStatus("cancel"));

  qs.bookingDate?.addEventListener("change", async () => {
    state.selectedDate = qs.bookingDate.value;
    state.selectedTime = "";
    await loadSlots();
  });
}

async function loadCatalog() {
  const { data, error } = await sb.rpc("public_catalog", {
    p_salon_slug: env.SALON_SLUG
  });

  if (error) throw error;
  if (!data) throw new Error("Catalog is empty");

  state.catalog = data;
  state.services = Array.isArray(data.services) ? data.services : [];
  state.staff = Array.isArray(data.staff) ? data.staff : [];

  const brandPrimary = data?.salon?.brandPrimary || data?.salon?.brand_primary || "#06C755";
  document.documentElement.style.setProperty("--line", brandPrimary);

  const heroDescription = document.getElementById("heroDescription");
  if (heroDescription && data?.salon?.name) {
    heroDescription.textContent =
      `${data.salon.name} 向けの設定済み予約導線です。サービス、担当者、空き時間をそのまま選べます。`;
  }
}

function renderServices() {
  qs.servicesList.innerHTML = "";

  state.services.forEach((service) => {
    const card = document.createElement("button");
    card.type = "button";
    card.className = "service-card";

    if (state.selectedService?.id === service.id) {
      card.classList.add("active");
    }

    const duration = service.durationMinutes ?? service.duration_minutes ?? "-";
    const price = service.priceJpy ?? service.price_jpy ?? "-";

    card.innerHTML = `
      <div class="card-title">${escapeHtml(service.name)}</div>
      <div class="card-sub">${escapeHtml(duration)}分 / ¥${escapeHtml(price)}</div>
    `;

    card.addEventListener("click", async () => {
      state.selectedService = service;

      if (
        state.selectedStaff &&
        !(state.selectedStaff.serviceIds || state.selectedStaff.service_ids || []).includes(service.id)
      ) {
        state.selectedStaff = null;
      }

      state.selectedTime = "";
      renderServices();
      renderStaff();
      updateSummary();

      if (state.selectedDate) {
        await loadSlots();
      }
    });

    qs.servicesList.appendChild(card);
  });
}

function renderStaff() {
  qs.staffList.innerHTML = "";

  const filtered = state.selectedService
    ? state.staff.filter((member) =>
        (member.serviceIds || member.service_ids || []).includes(state.selectedService.id)
      )
    : state.staff;

  filtered.forEach((member) => {
    const card = document.createElement("button");
    card.type = "button";
    card.className = "staff-card";

    if (state.selectedStaff?.id === member.id) {
      card.classList.add("active");
    }

    const startTime = member.startTime ?? member.start_time ?? "-";
    const endTime = member.endTime ?? member.end_time ?? "-";

    card.innerHTML = `
      <div class="card-title">${escapeHtml(member.name)}</div>
      <div class="card-sub">${escapeHtml(startTime)} - ${escapeHtml(endTime)}</div>
    `;

    card.addEventListener("click", async () => {
      state.selectedStaff = member;
      state.selectedTime = "";
      renderStaff();
      updateSummary();

      if (state.selectedDate) {
        await loadSlots();
      }
    });

    qs.staffList.appendChild(card);
  });
}

function initDate() {
  const today = new Date();
  const yyyyMmDd = today.toISOString().slice(0, 10);

  qs.bookingDate.min = yyyyMmDd;
  qs.bookingDate.value = yyyyMmDd;
  state.selectedDate = yyyyMmDd;

  renderTimeListEmpty("担当者を選択してください");
}

async function loadSlots() {
  updateSummary();

  if (!state.selectedService || !state.selectedStaff || !state.selectedDate) {
    renderTimeListEmpty("サービス・担当者・日付を選択してください");
    return;
  }

  setLoading(true);

  try {
    const { data, error } = await sb.rpc("available_slots", {
      p_salon_slug: env.SALON_SLUG,
      p_service_id: state.selectedService.id,
      p_staff_id: state.selectedStaff.id,
      p_date: state.selectedDate
    });

    if (error) throw error;

    renderSlots(data || []);
  } catch (error) {
    console.error("loadSlots error:", error);
    renderTimeListEmpty("空き状況の取得に失敗しました");
  } finally {
    setLoading(false);
  }
}

function renderSlots(slots) {
  qs.timeList.className = "slot-list";
  qs.timeList.innerHTML = "";

  if (!slots.length) {
    renderTimeListEmpty("空き時間がありません");
    return;
  }

  slots.forEach((slot) => {
    const time = slot.slot_time || slot.slotTime || slot;
    const btn = document.createElement("button");

    btn.type = "button";
    btn.className = "slot-btn";
    btn.textContent = time;

    if (state.selectedTime === time) {
      btn.classList.add("active");
    }

    btn.addEventListener("click", () => {
      state.selectedTime = time;
      renderSlots(slots);
      updateSummary();
    });

    qs.timeList.appendChild(btn);
  });
}

function renderTimeListEmpty(text) {
  qs.timeList.className = "slot-list empty-state";
  qs.timeList.innerHTML = escapeHtml(text);
}

function updateSummary() {
  const summaryService = document.getElementById("summaryService");
  const summaryStaff = document.getElementById("summaryStaff");
  const summaryDateTime = document.getElementById("summaryDateTime");

  if (summaryService) summaryService.textContent = state.selectedService?.name || "-";
  if (summaryStaff) summaryStaff.textContent = state.selectedStaff?.name || "-";
  if (summaryDateTime) {
    summaryDateTime.textContent =
      state.selectedDate && state.selectedTime
        ? `${state.selectedDate} ${state.selectedTime}`
        : "-";
  }
}

function fillReview() {
  document.getElementById("reviewService").textContent = state.selectedService?.name || "-";
  document.getElementById("reviewStaff").textContent = state.selectedStaff?.name || "-";
  document.getElementById("reviewDate").textContent = state.selectedDate || "-";
  document.getElementById("reviewTime").textContent = state.selectedTime || "-";
}

async function submitBooking() {
  const customerName = qs.customerName.value.trim();
  const customerPhone = normalizePhone(qs.customerPhone.value);

  if (!state.selectedService) return toast("サービスを選択してください");
  if (!state.selectedStaff) return toast("担当者を選択してください");
  if (!state.selectedDate) return toast("日付を選択してください");
  if (!state.selectedTime) return toast("時間を選択してください");
  if (!customerName) return toast("お名前を入力してください");
  if (!customerPhone) return toast("電話番号を入力してください");
  if (!isValidPhone(customerPhone)) return toast("電話番号の形式が正しくありません");

  const payload = {
    p_salon_slug: env.SALON_SLUG,
    p_service_id: state.selectedService?.id || null,
    p_staff_id: state.selectedStaff?.id || null,
    p_booking_date: state.selectedDate,
    p_start_time: state.selectedTime,
    p_customer_name: customerName,
    p_customer_phone: customerPhone,
    p_line_user_id: null,
    p_source: "web_demo"
  };

  console.log("selectedService object", state.selectedService);
  console.log("selectedStaff object", state.selectedStaff);
  console.log("create_public_booking payload", payload);
  console.log("create_public_booking payload json", JSON.stringify(payload));

  if (!payload.p_service_id) {
    console.error("Missing p_service_id", state.selectedService);
    return toast("サービスIDが取得できていません");
  }

  if (!payload.p_staff_id) {
    console.error("Missing p_staff_id", state.selectedStaff);
    return toast("担当者IDが取得できていません");
  }

  setLoading(true);

  try {
    const { data, error } = await sb.rpc("create_public_booking", payload);
    if (error) throw error;

    state.createdBooking = data;
    fillDoneState();
    goToDone();
    toast("予約を保存しました");
  } catch (error) {
    console.error("submitBooking error:", error);
    toast(mapRpcError(error));
  } finally {
    setLoading(false);
  }
}

async function changeCreatedBookingStatus(action) {
  const publicToken =
    state.createdBooking?.publicToken ||
    state.createdBooking?.public_token ||
    null;

  if (!publicToken) {
    return toast("トークンが見つかりません");
  }

  setLoading(true);

  try {
    const { data, error } = await sb.rpc("public_change_booking_status", {
      p_public_token: publicToken,
      p_action: action
    });

    if (error) throw error;

    state.createdBooking.status = data.status;
    document.getElementById("doneStatus").textContent = data.status;
    toast(action === "confirm" ? "予約を確認しました" : "予約をキャンセルしました");
  } catch (error) {
    console.error("changeCreatedBookingStatus error:", error);
    toast("状態変更に失敗しました");
  } finally {
    setLoading(false);
  }
}

async function submitLead() {
  const p_salon_name = document.getElementById("leadSalonName").value.trim();
  const p_owner_name = document.getElementById("leadOwnerName").value.trim();
  const p_contact_line = document.getElementById("leadContact").value.trim();
  const p_business_type = document.getElementById("leadBusinessType").value.trim();
  const p_note = document.getElementById("leadNote").value.trim();

  if (!p_salon_name || !p_owner_name || !p_contact_line) {
    return toast("店舗名・担当者名・連絡先を入力してください");
  }

  setLoading(true);

  try {
    const { error } = await sb.rpc("create_public_lead", {
      p_salon_slug: env.SALON_SLUG,
      p_salon_name,
      p_owner_name,
      p_contact_line,
      p_business_type,
      p_note,
      p_line_user_id: null,
      p_line_display_name: null,
      p_source: "mini_app"
    });

    if (error) throw error;

    toast("相談を送信しました");

    document
      .getElementById("leadSection")
      .querySelectorAll("input, textarea, select")
      .forEach((el) => {
        el.value = "";
      });
  } catch (error) {
    console.error("submitLead error:", error);
    toast("相談送信に失敗しました");
  } finally {
    setLoading(false);
  }
}

function fillDoneState() {
  const bookingId =
    state.createdBooking?.bookingId ||
    state.createdBooking?.booking_id ||
    "-";

  const publicToken =
    state.createdBooking?.publicToken ||
    state.createdBooking?.public_token ||
    "-";

  document.getElementById("doneDate").textContent = state.selectedDate || "-";
  document.getElementById("doneTime").textContent = state.selectedTime || "-";
  document.getElementById("doneService").textContent = state.selectedService?.name || "-";
  document.getElementById("doneStaff").textContent = state.selectedStaff?.name || "-";
  document.getElementById("doneStatus").textContent = state.createdBooking?.status || "-";
  document.getElementById("doneToken").textContent = publicToken;

  const doneBookingId = document.getElementById("doneBookingId");
  if (doneBookingId) {
    doneBookingId.textContent = bookingId;
  }
}

function goToStep(step) {
  state.step = step;
  renderStep();
}

function goToDone() {
  document.querySelectorAll(".step").forEach((el) => el.classList.remove("active"));
  document.getElementById("doneState").classList.add("active");
  document.getElementById("stepLabel").textContent = "✓";
}

function renderStep() {
  document.querySelectorAll(".step").forEach((el) => el.classList.remove("active"));
  const stepEl = document.getElementById(`step${state.step}`);
  if (stepEl) stepEl.classList.add("active");
  document.getElementById("stepLabel").textContent = String(state.step);
}

function handleBack() {
  if (state.step > 1) goToStep(state.step - 1);
}

function resetBookingFlow() {
  state.selectedService = null;
  state.selectedStaff = null;
  state.selectedDate = qs.bookingDate.value;
  state.selectedTime = "";
  state.createdBooking = null;

  qs.customerName.value = "";
  qs.customerPhone.value = "";

  renderServices();
  renderStaff();
  renderTimeListEmpty("担当者を選択してください");
  updateSummary();
  goToStep(1);
}

function normalizePhone(value) {
  return String(value || "").replace(/[^\d+]/g, "");
}

function isValidPhone(value) {
  return /^(\+81|0)\d{9,10}$/.test(value);
}

function mapRpcError(error) {
  const msg = String(error?.message || "");

  if (msg.includes("booking_in_past")) return "過去の時間は予約できません";
  if (msg.includes("slot_unavailable")) return "その時間はすでに埋まっています";
  if (msg.includes("slot_conflict")) return "その時間はすでに埋まっています";
  if (msg.includes("duplicate_booking")) return "近い時間帯に同じ予約があります";
  if (msg.includes("blocked_slot")) return "その時間は受付できません";
  if (msg.includes("booking_too_far")) return "予約可能期間を超えています";
  if (msg.includes("too_far_in_future")) return "予約可能期間を超えています";
  if (msg.includes("service_not_found")) return "サービスが見つかりません";
  if (msg.includes("staff_not_found")) return "担当者が見つかりません";
  if (msg.includes("staff_service_not_allowed")) return "この担当者ではそのサービスを受け付けできません";

  return "予約に失敗しました";
}

function setLoading(on) {
  qs.loading.classList.toggle("active", !!on);
}

function toast(text) {
  const el = document.createElement("div");
  el.className = "toast";
  el.textContent = text;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 2600);
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}